$(document).ready(function () {
  let globalArr = [];
  let modal = document.querySelector("#modalId");
  let form = document.querySelector(".needs-validation");

  let parentTable = $("#parentTable").DataTable({
    columns: [
      { data: "" },
      { data: "" },
      { data: "" },
      { data: "" },
      { data: "" },
      { data: "" },
    ],
  });

  // Future Date Validation
  $("#launchDate").attr("max", new Date().toLocaleDateString("en-CA"));

  // Get All input elements of nested Table
  const getEachItemInputValue = (id) => {
    const nestedDetails = document.getElementById(`nestedDetails--${id}`);
    if (!nestedDetails) return {};

    const inputs = nestedDetails.querySelectorAll("input, select");
    const nestedObj = {};

    inputs.forEach((i) => {
      nestedObj[i.name] = i.value;
    });
    return nestedObj;
  };

  // Child Table

  // Form Submission
  form.addEventListener("submit", function (e) {
    e.preventDefault();

    // Check Form Validations
    if (!form.checkValidity()) {
      e.stopPropagation();
      form.classList.add("was-validated");
    } else {
      console.log("submit");

      // Get Form Data
      const formData = new FormData(form);

      // Add action and show Buttons to mainObj
      const action = `
      <button 
        type="button" 
        class="btn btn-success edit-category" 
        id="edit-category"> Edit
      </button>
      
      <button 
        type="button" 
        class="btn btn-danger delete-category" 
        id="delete-category"> Delete
      </button>
    `;

      const showBtn = `
      <button type="button" class="btn btn-info show-category" id="show-category">Show</button>
    `;

      parentTable.row.add(categoryDetails).draw();

      let btnDelete = document.querySelectorAll("#delete-category");
      if (btnDelete) {
        btnDelete.forEach((b) => {
          b.addEventListener("click", function (e) {
            deleteCategory(e);
          });
        });
      }
    }

    form.reset();
  });

  // Delete row
  const deleteCategory = (e) => {
    let tr = e.target.closest("tr");
    let row = parentTable.row(tr);
    let rowData = row.data();

    let index = globalArr.findIndex((c) => {
      return c == rowData;
    });

    globalArr.splice(index, 1);
    row.remove().draw();
  };
});
